# quick_check.py
# quick_check.py
from gazette_helpers import find_league_logo, find_sponsor_logo
print(find_league_logo("BrownSeaKC"))
print(find_sponsor_logo("Gridiron Gazette"))

